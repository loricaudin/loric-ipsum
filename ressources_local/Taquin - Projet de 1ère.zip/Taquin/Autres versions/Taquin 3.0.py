###Bibliothèques :
from tkinter import Tk,Menu,Canvas,Label,Entry,StringVar,Button,Text #Créer fenetre
from tkinter.messagebox import showinfo,askquestion, showerror #Créer boites de dialogue
from tkinter.simpledialog import *
from tkinter.filedialog import *
from random import randint
try:
    from PIL import Image,ImageTk,ImageGrab #ImageGrab permet de faire des captures de la fenetre Tkinter ou d'une partie de la fenetre. Utile pour découper des images personnalisées et les utiliser pour le taquin
except:
    input("Impossible d'importer le module Pillow, veuillez l'installer avec pip install Pillow. Pour l'installer, veullez faire Ctrl+K et entrer dans le shell (si vous utiliser Pyzo) : pip install Pillow")
###Foctions :
#Livre des records
def lecture_fichier(nom):
    """
    
    Cette fonction essaye de lire le fichier records.txt, si ce fichier n'existe pas ou est introuvable, un nouveau fichier du même nom est crée. Puis on récupère les données de ce fichier pour l'enregistrer dans une liste qui sera retournée.
    
    """
    try: #On essaye d'ouvrir le fichier records.txt :
        fichier=open(nom,"r",encoding='utf-8')
    except: #=Si le fichier est introuvable ou si l'ouverture provoque une erreur :
        print("Fichier records.txt introuvable.\nCréation d'un nouveau fichier records.txt")
        fichier=open(nom,"w",encoding='utf-8')
        fichier.write("Nom_du_joueur,Record en s\n")
        fichier.close()
        fichier=open(nom,"r",encoding='utf-8')
    liste=[]
    fichier.readline() #Lire la ligne 1 sans la récupérer : Nom_du_joueur,Record\n
    c=fichier.readline()
    while c!="":
        c=c.split(",")
        c[-1]=c[-1][:-1]
        liste.append(c)
        c=fichier.readline()
    
    fichier.close()
    return liste

def enregistrer_score():
    """
    
    Cette fonction efface le contenu du fichier records.txt et réécrit le contenu de la liste liste_records, une variable globale dans le fichier records.txt
    
    """
    global liste_records
    fichier=open("records.txt","w",encoding='utf-8')
    fichier.write("Nom_du_joueur,Record\n")
    for l in liste_records:
        fichier.write(l[0]+","+l[1]+"\n")
    fichier.close()
    showinfo("Taquin","Le score a été enregistré")

def recherche_nom(l,nom):
    """
    
    Cette fonction recherche dans la liste l si le nom du joueur que nous avons entré et récuperé dans la variable nom est présent et récupère le record, si il est introuvable, le nom est ajouté à la liste
    
    """
    n=0
    numero_du_joueur=None
    try:
        for nom_et_record in l:
            if nom==nom_et_record[0]:
                numero_du_joueur=n
            n=n+1
    except:
        pass
    if numero_du_joueur==None:
        numero_du_joueur=n
        l.append([nom,"86400"])
    return numero_du_joueur,l

#Aspect graphique du jeu :
def a_propos():
    showinfo("Taquin","Taquin :\ncrée par Loric Audin et Robin Sadde.\nCopyright 2021 - Tous droits réservés")

def creation_carres():        
    global carres,position_carres,choix
    for i in range(8):
        image="Carres\carre_"+str(choix)+"_"+str(i+1)+".png"
        imTk=ImageTk.PhotoImage(Image.open(image),master=fenetre)
        x,y=position_carres[0][0],position_carres[0][1]
        del position_carres[0]
        imCv=zone_graphique.create_image(x,y,anchor="nw",image=imTk)
        carres.append([imTk,imCv])
    

def creer_barre_menu():
    menu_A=Menu(fenetre)
    menu_A.add_command(label="Ajouter une image personnalisée",command=image_perso)
    menu_A.add_command(label="Recommencer",command=redemarrer)
    menu_A.add_command(label="Quitter",command=fermer)

    menu_B=Menu(fenetre)
    menu_B.add_command(label="Règle du jeu",command=regle_du_jeu)
    menu_B.add_command(label="À propos de nous",command=a_propos)

    mon_menu=Menu(fenetre)
    mon_menu.add_cascade(label="Jeu",menu=menu_A)
    mon_menu.add_cascade(label="?",menu=menu_B)

    fenetre["menu"]=mon_menu

def creer_fenetre():
    fenetre=Tk()
    fenetre.title("Taquin")
    return fenetre

def creer_texte():
    """
    Création du texte avec le temps juste à côté qui sera au fur et à mesure modifié dans la fonction temps().
    """
    texte_temps=zone_graphique.create_text(50,490,text="Temps : 0 s",fill="white",font="Arial 10")
    texte_record=zone_graphique.create_text(430,490,text="Meilleur temps : "+str(liste_records[numero_du_joueur][1])+" s",fill="white",font="Arial 10")
    return texte_temps

def creer_widgets():
    zone_graphique=Canvas(fenetre,width=500,height=500,bg="black")
    zone_graphique.grid(row=0,column=0,columnspan=3)
    
    mon_texte=Label(fenetre,text="Entre un nom : ")
    mon_texte.grid(row=1,column=0)
    
    champ_saisie=Entry(fenetre,textvariable=StringVar())
    champ_saisie.grid(row=1,column=1)
    
    bouton=Button(fenetre,text="Valider",width=12,command=saisir)
    bouton.grid(row=1,column=2)
    
    return zone_graphique,mon_texte,champ_saisie,bouton

def derniere_image():
    """
    Cette fonction affiche la dernière image si elle respecte les 8 conditions à la fin de la fonction deplacement, c'est-à-dire, que les 8 carrés soient rangés dans l'ordre.
    """
    global score
    image="Carres\carre_"+str(choix)+"_"+str(9)+".png"
    imTk=ImageTk.PhotoImage(Image.open(image),master=fenetre)
    imCv=zone_graphique.create_image(325,325,anchor="nw",image=imTk)
    fin(score)
    return [imTk,imCv]

def redemarrer():
    global partie
    partie=True
    fenetre.destroy()

def fermer():
    showinfo("Taquin","Merci d'avoir joué à ce jeu.")
    fenetre.destroy()

#Importation image personnalisée
def image_perso():
    #Permet de choisir une image personalisée
    global choix,image_persoImCv,image_persoImTk
    c=False
    choix=6
    while choix<0 or choix>5 and c==False:
        if c==True:
            showerror("Taquin","Veuillez entrer un nombre entre 0 et 5")
        choix=askinteger("Taquin","Entrer le numéro de l'image qui vous intéresse :\n0:Image personnalisée 1:Voiture 2:Rien 3:Tableau de Kawz 4:Rien 5:Rien")
        c=True
        if choix==None:
            choix=0
            c="Aléatoire"
    if choix==0 and c!="Aléatoire":
        ouverture_image_perso()
    elif c=="Aléatoire":
        choix=randint(0,5)

def ouverture_image_perso():
    global image_persoImCv,image_persoImTk,fenetre2,fichier,zone_graphique2
    lien=askopenfilename(title="Insérer une image",filetypes=(("Tous les fichiers","*.*"),("Image png","*.png"),("Image jpeg","*.jpg")))
    fichier=""
    
    """
    
    À partir de là, nous allons récuperer l'emplacement de l'image grâce à la variable lien
    
    """
    
    if lien!="":
        fichier=lien[3:]
        n=0
        e=""
        for l in fichier:
            if l=="/":
                n=n+1
                e=e+"\\"
            else:
                e=e+l
        m=1
        e=lien[:3]+e   
        fichier=e
        try:
            #Création d'une fenetre à part :
            fenetre2=Toplevel(fenetre)
            zone_graphique2=Canvas(fenetre2,width=452,height=452,bg="black")
            zone_graphique2.grid(row=0,column=0,rowspan=2)
            texte2=Label(fenetre2,text="Pour déplacer votre image,\nutiliser les flèches,\npour agrandir, appuyez \nsur a, pour réduire, appuyez \nsur z.")
            texte2.grid(row=0,column=1)
            bouton2=Button(fenetre2,text="Sauvegarder",width=12,command=save_image_perso)
            bouton2.grid(row=1,column=1)
            #Importation image
            image_persoImTk=ImageTk.PhotoImage(ImageTk.Image.open(fichier),master=fenetre2)
            image_persoImCv=zone_graphique2.create_image(226,226,anchor="center",image=image_persoImTk)
            fenetre2.bind("<Left>",gauche2)
            fenetre2.bind("<Right>",droite2)
            fenetre2.bind("<Up>",haut2)
            fenetre2.bind("<Down>",bas2)
            fenetre2.bind("<a>",agrandir2)
            fenetre2.bind("<z>",reduire2)
            #showinfo("Taquin - Ajouter Image","Pour déplacer votre image, utiliser les flèches, pour agrandir, appuyez sur a, pour réduire, appuyez sur z.")
        except:
            showerror("Taquin - Ajouter Image - Erreur","Impossible d'ouvrir cette image. Peut-être l'extension est incorrect ou l'image a été endommagée.")

def save_image_perso():
    """
    
    Cette fonction "découpe" les images pour les enregistrer et les rouvrir dans le jeu : pour cela, nous allons faire une capture d'écran de notre fenêtre. Pour s'y faire, nous devons récuperer les coordonnées de la fenetre avec x = fenetre2.winfo_rootx() et y = fenetre2.winfo_rooty(). Puis nous faisons une capture d'écaran avec ImageGrab.grab((x,y,x+150,y+150)) et nous sauvegardons.
    
    """
    global choix
    numéro="perso"
    x = fenetre2.winfo_rootx()
    y = fenetre2.winfo_rooty()
    x=x+2
    y=y+2
    n=0
    for i in range(3):
        for j in range(3):
            fenetre.after(500)
            n=n+1
            im = ImageGrab.grab((x,y,x+150,y+150))
            image="Carres/carre_"+str(numéro)+"_"+str(n)+".png"
            im.save(image)
            x=x+150
        y=y+150
        x = fenetre2.winfo_rootx()
        x=x+2
    showinfo("Taquin - Ajouter image - Enregistré","L'image a été enregistrée et découpée avec succès.")
    choix="perso"
    fenetre2.destroy()

def agrandir2(_):
    global image_persoImCv,image_persoImTk,xi,yi
    x,y=zone_graphique2.coords(image_persoImCv)
    image_persoImCv = ImageTk.Image.open(fichier)
    if xi=="" and yi=="":
        xi, yi = image_persoImCv.size #Récupère la longueur et la hauteur
    xi,yi=xi+xi/100,yi+yi/100
    image_persoImCv = image_persoImCv.resize((int(xi), int(yi)),  ImageTk.Image.ANTIALIAS)#Modifie la taille
    image_persoImTk = ImageTk.PhotoImage(image=image_persoImCv)
    image_persoImCv=zone_graphique2.create_image(x,y,anchor="center",image=image_persoImTk)
    
def reduire2(_):
    global image_persoImCv,image_persoImTk,xi,yi
    x,y=zone_graphique2.coords(image_persoImCv)
    image_persoImCv = ImageTk.Image.open(fichier)
    if xi=="" and yi=="":
        xi, yi = image_persoImCv.size
    xi,yi=xi-xi/100,yi-yi/100
    image_persoImCv = image_persoImCv.resize((int(xi), int(yi)), ImageTk.Image.ANTIALIAS)
    image_persoImTk = ImageTk.PhotoImage(image=image_persoImCv)
    image_persoImCv=zone_graphique2.create_image(x,y,anchor="center",image=image_persoImTk)

def gauche2(_):
    x,y=zone_graphique2.coords(image_persoImCv)
    zone_graphique2.coords(image_persoImCv,x+2,y)

def droite2(_):
    x,y=zone_graphique2.coords(image_persoImCv)
    zone_graphique2.coords(image_persoImCv,x-2,y)

def haut2(_):
    x,y=zone_graphique2.coords(image_persoImCv)
    zone_graphique2.coords(image_persoImCv,x,y+2)

def bas2(_):
    x,y=zone_graphique2.coords(image_persoImCv)
    zone_graphique2.coords(image_persoImCv,x,y-2)

#Fonction gérant le temps et ajoute 1 par secondes si on commence le jeu (action=True) jusqu'à ce qu'on ait fini (action=False)
def temps():
    global texte_temps,score,action
    if action==True:
        score = score + 1
        new_texte="Temps : "+str(score)+" s"
        zone_graphique.itemconfigure(texte_temps,text=new_texte)
        fenetre.after(1000, lambda : temps())

#Règles du jeu :
def regle_du_jeu():
    showinfo("Taquin","Les règles sont simple, vous devez remettre toutes les pièces du puzzle dans le bon ordre, en partant d'une disposition initiale où elles sont mélangées.")
    showinfo("Taquin","Pour ce faire, déplacez les pièces en cliquant dessus à la souris ou en utilisant les flèches de votre clavier (touches ← ↑ → ↓). Avec la souris vous pouvez déplacer en même temps plusieurs pièces d'une même ligne ou d'une même colonne. Seules les pièces situées sur la même ligne ou la même colonne que le trou peuvent être déplacées. La position finale est atteinte lorsque les pièces sont toutes disposées dans l'ordre croissant, de gauche à droite et de haut en bas (la pièce n°1 doit donc être en haut à gauche).")

def saisir():
    global liste_records,numero_du_joueur
    nom=champ_saisie.get()
    if nom!="":
        numero_du_joueur,liste_records=recherche_nom(liste_records,nom)
        nom="Joueur : "+nom
        mon_texte.configure(text=nom)
        champ_saisie.destroy()
        bouton.configure(text="Go",command=go)

def nouveau_record(n,nouveau):
    liste_records[n][1]=str(nouveau)
    showinfo("Taquin","Vous avez établi un nouveau record : "+str(nouveau))
    answer=askquestion("Taquin","Voulez-vous enregistrer ce record ?")
    if answer=="yes":enregistrer_score()
    
def fin(score):
    global numero_du_joueur,liste_records,action,position_carres,partie
    action=False
    showinfo("Taquin","Vous avez gagné !")
    if int(liste_records[numero_du_joueur][1])>score:
        nouveau_record(numero_du_joueur,score)
    answer=askquestion("Taquin","Voulez-vous rejouer ?")
    if answer=="no":fermer()
    else:redemarrer()

#Jeu :

def deplacement(n,l,position_carres,t=0):
    global action
    #Déplacement en bas :
    if n==0:
        if action==True:
            for c in carres:
                xcarre,ycarre=zone_graphique.coords(c[1])
                if xcarre-l[0]==0 and ycarre-l[1]==0:
                    zone_graphique.coords(c[-1],position_carres[0][0],position_carres[0][1])
                    position_carres[0][0],position_carres[0][1]=xcarre,ycarre
        else:
            for i in range(len(position_carres)):
                if position_carres[i][0]-t[0]==0 and position_carres[i][1]-t[1]==150:
                    position_carres[i],t=t,position_carres[i]
                    break
                
    #Déplacement en haut :
    if n==1:
        if action==True:
            for c in carres:
                xcarre,ycarre=zone_graphique.coords(c[1])
                if xcarre-l[0]==0 and ycarre-l[1]==0:
                    zone_graphique.coords(c[-1],position_carres[0][0],position_carres[0][1])
                    position_carres[0][0],position_carres[0][1]=xcarre,ycarre
        else:
            for i in range(len(position_carres)):
                if position_carres[i][0]-t[0]==0 and t[1]-position_carres[i][1]==150:
                    position_carres[i],t=t,position_carres[i]
                    break
    #Déplacement à gauche :
    if n==2:
        if action==True:
            for c in carres:
                xcarre,ycarre=zone_graphique.coords(c[1])
                if xcarre-l[0]==0 and ycarre-l[1]==0:
                    zone_graphique.coords(c[-1],position_carres[0][0],position_carres[0][1])
                    position_carres[0][0],position_carres[0][1]=xcarre,ycarre
        else:
            for i in range(len(position_carres)):
                if position_carres[i][0]-t[0]==150 and t[1]-position_carres[i][1]==0:
                    position_carres[i],t=t,position_carres[i]
                    break
    #Déplacement à droite :
    if n==3:
        if action==True:
            for c in carres:
                xcarre,ycarre=zone_graphique.coords(c[1])
                if xcarre-l[0]==0 and ycarre-l[1]==0:
                    zone_graphique.coords(c[-1],position_carres[0][0],position_carres[0][1])
                    position_carres[0][0],position_carres[0][1]=xcarre,ycarre
        else:
            for i in range(len(position_carres)):
                if t[0]-position_carres[i][0]==150 and t[1]-position_carres[i][1]==0:
                    position_carres[i],t=t,position_carres[i]
                    break
    return t,position_carres
        

def clic(event):
    """
    Cette fonction permet de déplacer les carrés avec la souris
    """
    global position_carres,carres,action
    if action==True:
        x=event.x
        y=event.y
        for l in position_defaut:
            if l[0]<x and l[0]+150>x and l[1]<y and l[1]+150>y:
                if l[0]-position_carres[0][0]==0 and position_carres[0][1]-l[1]==150:
                    t,position_carres=deplacement(0,l,position_carres)
                if l[0]-position_carres[0][0]==0 and l[1]-position_carres[0][1]==150:
                    t,position_carres=deplacement(1,l,position_carres)
                if l[0]-position_carres[0][0]==150 and l[1]-position_carres[0][1]==0:
                    t,position_carres=deplacement(2,l,position_carres)
                if position_carres[0][0]-l[0]==150 and l[1]-position_carres[0][1]==0:
                    t,position_carres=deplacement(3,l,position_carres)
        
        
        
        #Vérifier si on a gagné :
        place=[]
        for c in carres:
            xcarre,ycarre=zone_graphique.coords(c[1])
            place.append([xcarre,ycarre])
        ncarre=0
        #Les 8 conditions pour afficher la dernière image et arrêter le jeu :
        for i in range(8):
            if place[i][0]==position_defaut[i][0] and place[i][1]==position_defaut[i][1]:
                ncarre=ncarre+1
        if ncarre==8:
            carres.append(derniere_image())
        
def position_hasard_carres(t=[325,325]):
    global position_carres,action,position_defaut
    """
    
    Cette fonction bouclée à l'infini tant que action==False mélange les pièces, mais pas n'importe comment, de sorte à pouvoir obtenir à la fin :

    |1|2|3|                   |1|2|3|  Si on ne
    |4|5|6|   et non pas :    |4|5|6|  mélange pas
    |7|8| |                   |8|7| |  correctement.

On est donc obligé de déplacer nous même les pièces (par exemple on déplace le 8 vers la droite, puis le 5 vers le bas...)
    
    """
    if action==False:
        #Ce que nous allons faire aujoud'hui :
        t,position_carres=deplacement(randint(0,3),[0,0],position_carres,t)
        position_carres[-1]=t
        fenetre.after(1,lambda:position_hasard_carres(t))
    
    

def go():
    global numero_du_joueur,position_carres,texte_temps,action,score
    if action==False:
        try:
            fenetre2.destroy()
        except:
            pass
        creation_carres()
        action=True
        score=0
        texte_temps=creer_texte()
        temps() #Démarrer le chrono

def test(_):
    print(position_carres,action,position_defaut,carres)
###Variables globales
partie=True #Permet de déterminer si on souhaite jouer ou s'arrêter lorsque l'on dépasse fenetre.mainloop()
while partie==True:
    partie=False
    numero_du_joueur=0
    score=0
    image_persoImCv,image_persoImTk,xi,yi,fenetre2,zone_graphique2,fichier="","","","","","","" #Utilisé seulement si on choisit une image personnalisée
    carres=[]
    action=False
    texte_temps=0
    choix=randint(1,5)
    choix=1 #Test
    position_carres=[[25,25],[175,25],[325,25],[25,175],[175,175],[325,175],[25,325],[175,325],[325,325]]
    position_defaut=[[25,25],[175,25],[325,25],[25,175],[175,175],[325,175],[25,325],[175,325],[325,325]]
###Programme principal :
#Aspect graphique du jeu :
    fenetre=creer_fenetre()
    position_hasard_carres()
    zone_graphique,mon_texte,champ_saisie,bouton=creer_widgets()
    creer_barre_menu()
    liste_records=lecture_fichier("records.txt")
#Jeu :
    zone_graphique.bind("<ButtonPress-1>",clic)
    fenetre.bind("<w>",test)
    fenetre.mainloop()