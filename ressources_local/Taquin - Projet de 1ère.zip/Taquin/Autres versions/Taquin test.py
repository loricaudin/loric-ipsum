###Bibliothèques :
from tkinter import Tk,Menu,Canvas,Label,Entry,StringVar,Button,Text #Créer fenetre
from tkinter.messagebox import showinfo,askquestion #Créer boites de dialogue
try:
    from PIL import Image,ImageTk
except:
    input("Impossible d'importer le module Pillow, veuillez l'installer avec pip install Pillow. Pour l'installer, veullez faire Ctrl+K et entrer dans le shell (si vous utiliser Pyzo) : pip install Pillow")
###Foctions :
#Livre des records
def lecture_fichier(nom):
    """
    
    Cette fonction essaye de lire le fichier records.txt, si ce fichier n'existe pas ou est introuvable, un nouveau fichier du même nom est crée. Puis on récupère les données de ce fichier pour l'enregistrer dans une liste qui sera retournée.
    
    """
    try: #On essaye d'ouvrir le fichier records.txt :
        fichier=open(nom,"r",encoding='utf-8')
    except: #=Si le fichier est introuvable ou si l'ouverture provoque une erreur :
        print("Fichier records.txt introuvable.\nCréation d'un nouveau fichier records.txt")
        fichier=open(nom,"w",encoding='utf-8')
        fichier.write("Nom_du_joueur,Record\n")
        fichier.close()
        fichier=open(nom,"r",encoding='utf-8')
    liste=[]
    fichier.readline() #Lire la ligne 1 sans la récupérer : Nom_du_joueur,Record\n
    c=fichier.readline()
    while c!="":
        c=c.split(",")
        c[-1]=c[-1][:-1]
        liste.append(c)
        c=fichier.readline()
    
    fichier.close()
    return liste

def enregistrer_score():
    """
    
    Cette fonction efface le contenu du fichier records.txt et réécrit le contenu de la liste liste_records, une variable globale dans le fichier records.txt
    
    """
    global liste_records
    fichier=open("records.txt","w",encoding='utf-8')
    fichier.write("Nom_du_joueur,Record\n")
    for l in liste_records:
        fichier.write(l[0]+","+l[1]+"\n")
    fichier.close()
    showinfo("Taquin","Le score a été enregistré")

def recherche_nom(l,nom):
    n=0
    numero_du_joueur=None
    try:
        for nom_et_record in l:
            if nom==nom_et_record[0]:
                numero_du_joueur=n
            n=n+1
    except:
        pass
    if numero_du_joueur==None:
        numero_du_joueur=n
        l.append([nom,"86400"])
    return numero_du_joueur,l

#Aspect graphique du jeu :
def a_propos():
    showinfo("Taquin","Taquin :\ncrée par Loric Audin et Robin Sadde.\nCopyright 2021 - Tous droits réservés")
    
def creer_barre_menu():
    menu_A=Menu(fenetre)
    menu_A.add_command(label="Quitter",command=fermer)

    menu_B=Menu(fenetre)
    menu_B.add_command(label="Règle du jeu",command=regle_du_jeu)
    menu_B.add_command(label="À propos de nous",command=a_propos)

    mon_menu=Menu(fenetre)
    mon_menu.add_cascade(label="Jeu",menu=menu_A)
    mon_menu.add_cascade(label="?",menu=menu_B)

    fenetre["menu"]=mon_menu

def creer_fenetre():
    fenetre=Tk()
    fenetre.title("Taquin")
    return fenetre

def creer_widgets():
    zone_graphique=Canvas(fenetre,width=500,height=500,bg="black")
    zone_graphique.grid(row=0,column=0,columnspan=3)
    
    mon_texte=Label(fenetre,text="Entre un nom : ")
    mon_texte.grid(row=1,column=0)
    
    champ_saisie=Entry(fenetre,textvariable=StringVar())
    champ_saisie.grid(row=1,column=1)
    
    bouton=Button(fenetre,text="Valider",width=12,command=saisir)
    bouton.grid(row=1,column=2)
    
    return zone_graphique,mon_texte,champ_saisie,bouton

def fermer():
    showinfo("Taquin","Merci d'avoir joué à ce jeu.")
    fenetre.destroy()

#Règles du jeu :
def regle_du_jeu():
    showinfo("Taquin","Les règles sont simple, vous devez remettre toutes les pièces du puzzle dans le bon ordre, en partant d'une disposition initiale où elles sont mélangées.")
    showinfo("Taquin","Pour ce faire, déplacez les pièces en cliquant dessus à la souris ou en utilisant les flèches de votre clavier (touches ← ↑ → ↓). Avec la souris vous pouvez déplacer en même temps plusieurs pièces d'une même ligne ou d'une même colonne. Seules les pièces situées sur la même ligne ou la même colonne que le trou peuvent être déplacées. La position finale est atteinte lorsque les pièces sont toutes disposées dans l'ordre croissant, de gauche à droite et de haut en bas (la pièce n°1 doit donc être en haut à gauche).")

def saisir():
    global liste_records,numero_du_joueur
    nom=champ_saisie.get()
    if nom!="":
        numero_du_joueur,liste_records=recherche_nom(liste_records,nom)
        nom="Joueur : "+nom
        mon_texte.configure(text=nom)
        champ_saisie.destroy()
        bouton.configure(text="Go",command=go)

def go():
    pass

###Variables globales

###Programme principal :
#Aspect graphique du jeu :
fenetre=creer_fenetre()
zone_graphique,mon_texte,champ_saisie,bouton=creer_widgets()
creer_barre_menu()
#Jeu :

fenetre.mainloop()