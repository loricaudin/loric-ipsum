###Bibliothèques :
from tkinter import Tk, Canvas
from PIL import Image,ImageTk,ImageGrab
from tkinter.messagebox import *
from tkinter.filedialog import *
from tkinter.simpledialog import *
from tkinter.colorchooser import *
###Fonctions :
def creer_fenetre():
    fenetre=Tk()
    fenetre.title("Taquin - Ajouter image")
    zone_graphique=Canvas(fenetre,width=452,height=452,bg="white")
    zone_graphique.grid(row=0,column=0,columnspan=3)
    return fenetre,zone_graphique

def creer_barre_menu():
    menu_A=Menu(fenetre)
    menu_A.add_command(label="Quitter",command=fenetre.destroy)

    menu_B=Menu(fenetre)
    menu_B.add_command(label="Image",command=ouvrir)
    
    menu_Z=Menu(fenetre)
    menu_Z.add_command(label="À propos de nous",command=a_propos)

    mon_menu=Menu(fenetre)
    mon_menu.add_cascade(label="Jeu",menu=menu_A)
    mon_menu.add_cascade(label="Sauvegarder et quitter",command=enregistrer)
    mon_menu.add_cascade(label="Insertion",menu=menu_B)
    mon_menu.add_cascade(label="?",menu=menu_Z)

    fenetre["menu"]=mon_menu
def a_propos():
    showinfo("Taquin - Ajouter image","Taquin - Ajouter image :\ncrée par Loric Audin.\nCopyright 2021 - Tous droits réservés")
    
def enregistrer():
    numéro=askinteger("Taquin - Ajouter Image","Entrer le numéro de votre image :")
    if numéro=="":
        numéro="perso"
    x = fenetre.winfo_rootx()
    y = fenetre.winfo_rooty()
    x=x+2
    y=y+2
    n=0
    for i in range(3):
        for j in range(3):
            fenetre.after(500)
            n=n+1
            im = ImageGrab.grab((x,y,x+150,y+150))
            image="Carres/carre_"+str(numéro)+"_"+str(n)+".png"
            im.save(image)
            x=x+150
        y=y+150
        x = fenetre.winfo_rootx()
        x=x+2
    showinfo("Taquin - Ajouter image - Enregistré","Images enregistré.")

def ouvrir():
    global fichier,photo,obj,rond,mon_rond,xi, yi
    lien=askopenfilename(title="Insérer une image",filetypes=(("Tous les fichiers","*.*"),("Image png","*.png"),("Image jpeg","*.jpg")))
    fichier=""
    if lien!="":
        fichier=lien[3:]
        n=0
        e=""
        for l in fichier:
            if l=="/":
                n=n+1
                e=e+"\\"
            else:
                e=e+l
        m=1
        e=lien[:3]+e   
        """
        while m!=n:
            m=m+1
            e="..\\"+e
            if m==n:
                e="\\"+e
        """
        fichier=e
        try:
            obj=ImageTk.PhotoImage(ImageTk.Image.open(fichier),master=fenetre)
            photo=zone_graphique.create_image(250,250,anchor="center",image=obj)
            xi, yi="",""
            showinfo("Taquin - Ajouter Image","Pour déplacer votre image, utiliser les flèches, pour agrandir, appuyez sur a, pour réduire, appuyez sur z.")
        except:
            showerror("Taquin - Ajouter Image - Erreur","Impossible d'ouvrir cette image. Peut-être l'extension est incorrect ou l'image a été endommagée.")

###Evenements :
def agrandir(_):
    global photo,obj,xi,yi
    x,y=zone_graphique.coords(photo)
    photo = ImageTk.Image.open(fichier)
    if xi=="" and yi=="":
        xi, yi = photo.size
    xi,yi=xi+xi/100,yi+yi/100
    photo = photo.resize((int(xi), int(yi)), ImageTk.Image.ANTIALIAS)
    obj = ImageTk.PhotoImage(image=photo)
    photo=zone_graphique.create_image(x,y,anchor="center",image=obj)
    
def reduire(_):
    global photo,obj,xi,yi
    x,y=zone_graphique.coords(photo)
    photo = ImageTk.Image.open(fichier)
    if xi=="" and yi=="":
        xi, yi = photo.size
    xi,yi=xi-xi/100,yi-yi/100
    photo = photo.resize((int(xi), int(yi)), ImageTk.Image.ANTIALIAS)
    obj = ImageTk.PhotoImage(image=photo)
    photo=zone_graphique.create_image(x,y,anchor="center",image=obj)

def gauche(_):
    try:
        x,y=zone_graphique.coords(photo)
        zone_graphique.coords(photo,x+2,y)
    except:
        pass

def droite(_):
    try:
        x,y=zone_graphique.coords(photo)
        zone_graphique.coords(photo,x-2,y)
    except:
        pass

def haut(_):
    try:
        x,y=zone_graphique.coords(photo)
        zone_graphique.coords(photo,x,y+2)
    except:
        pass

def bas(_):
    try:
        x,y=zone_graphique.coords(photo)
        zone_graphique.coords(photo,x,y-2)
    except:
        pass
###Viariables globales :
fichier=""
photo=""
obj=""
texte=""
rond,mon_rond="",""
xi,yi="",""
texte1,texte2,texte3="","",""
mémoire=""
couleur="black"
###Programme principal :
fenetre,zone_graphique=creer_fenetre()
fenetre.bind("<Left>",gauche)
fenetre.bind("<Right>",droite)
fenetre.bind("<Up>",haut)
fenetre.bind("<Down>",bas)
fenetre.bind("<a>",agrandir)
fenetre.bind("<z>",reduire)
creer_barre_menu()


fenetre.mainloop()